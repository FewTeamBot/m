# -*- coding: utf-8 -*-
# -*- Copyleft @ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻-*-

import LineNeo
from LineNeo.lib.curve.ttypes import *
from io import StringIO
from datetime import datetime
import time,random,sys,json,codecs,threading,glob,sys
import re,string,os
import os.path,sys,urllib,shutil,subprocess

cl = LineNeo.LINE()
cl.login(token="Em8Oc1pIpvTyTVAOY7gc.oXcw7XjJm93ADS88LIBwda.Ryb+StQ05MOXs7ASwnXHVf1iO9Nz9JpK59+SziNnu6s=")
cl.loginResult()

ki = LineNeo.LINE()
ki.login(token="EmchG16uYHq5i86B8HQ4.0oS9vv/6KAacfbd8Ryxq9a.t08d/UYiPeDQujBUqjfNwPR690GWbTG+9Z5H3yqCB/w=")
ki.loginResult()

kk = LineNeo.LINE()
kk.login(token="EmdZ9R0qF8ynBF0vh890.0YSiYgQ+/7fHLUl35wnpWa.yFgvAIjvb7RJHArL52DegItzNYMSv9iw3Hsw+ANaPYM=")
kk.loginResult()

kc = LineNeo.LINE()
kc.login(token="Eml2KVelwtlU5HOQdTj5.e5nnHardiVuE9d1hv8yF9q.UgHhNI69KkuxmiIZKhUMeI0y6FrtcuUuSzIIZUgoxnw=")
kc.loginResult()

print u"\n⭐⭐Neo Bot Ready RUNING⭐⭐\n"
reload(sys)
sys.setdefaultencoding('utf-8')
helpMessage ="""
╔═════════════╗
╟      ❝NEO SLEFBOT❞
╟ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈
╚═════════════╝
❝COMMAND MESSAGES❞
╔═════════════╗
║➽Me
║➽Id
║➽Mid
║➽Gn:
║➽Cn:
║➽Up
║➽Tl:
║➽Cc:
║➽Gid
║➽Mc @
║➽Gift
║➽Cbc:
║➽Gbc
║➽Cek @
║➽Check @
║➽Smule
║➽Youtube
║➽Xvedeo
║➽Google
║➽Translete
║➽Tag
║➽Add message:
║➽Message
║➽Glist
║➽Ginfo
║➽Allglist
║➽Allgid
║➽Allmid
║➽Set/Status
║➽Rgroups
║➽Ban
║➽Unban
║➽Ban:on repeat
║➽Unban:on repeat
║➽Repeat:off
║➽Clear ban
║➽Rename:
║➽Myname:
║➽Bot1 name:
║➽Bot2 name:
║➽Bot3 name
║➽All copy @
║➽Neo1 clone:on @
║➽Neo2 clone:on @
║➽Neo3 clone:on @
║➽Tkick @
║➽Spam:on
║➽Spamm 100 @
║➽Gift @
║➽All gift @
║➽Gift:5
║➽Bot gift 5
║➽All gift 5
║➽Banlist
║➽Umid @
║➽Uid @
║➽Uimages @
║➽Ubeygroud @
║➽Clean invite
║➽Cancel invite
║➽My groups
║➽My group id
║➽Blocklist
║➽Add/Remove staff
╚═════════════╝
❝COMMAND IN THE GROUPS❞
╔═════════════╗
║➽All join
║➽Gcreator
║➽Creator
║➽G creator
║➽Gn:
║➽Sp/Speed
║➽Urlon
║➽Urloff
║➽Gurl
║➽Tαgαll
║➽Čσρу@
║➽Ban1@
║➽Unban1 @
║➽Cekban
║➽Invite:
║➽Creator
║➽Invite:on
║➽Cancel
║➽Kick:
║➽Nk:@
║➽Neo join
║➽Neo @bye
║➽̷Respon
║➽Bot1 glist
║➽Bot1 rename:
║➽Bot1 gurl
║➽Bot1 urlon
║➽Bot1 urloff
║➽Bot1 gourl:
║➽Bot invite:
║➽Bot1 cancel
║➽Bot1 Tag
║➽Kill
║➽Purge
║➽Kicall
║➽Neo1/2/3
║➽Kill ban
║➽Kick @
║➽Tkick @
║➽Neo1 kick @
║➽Neo2 kick @
║➽Neo3 kick @
║➽Cleanse
║➽Bot creator
║➽Neo1 creator
║➽Neo1 tag
║➽Neo2 tag
║➽Neo3 tag
║➽Broadcast:
║➽Pmcast:
║➽Groupcast:
║➽Neo1 pmcast:
║➽Neo2 pmcast:
║➽Neo3 pmcast:
║➽Neo1 groupcast:
║➽Neo2 groupcast:
║➽Neo3 groupcast:
╚═════════════╝
    ❝COMMAND SETTINGS❞
╔═════════════╗
║➽Clock:on/off
║➽Contact: on/off
║➽Share :on/off
║➽Gcancel number/off
║➽Protect url:on/off
║➽Auto add:on/off
║➽Auto join:on/off
║➽Auto leave:on/off
║➽Welcome:on/off
║➽Auto like:on/off
║➽Backup on/off
║➽Auto purge:on/off
║➽Pqr:on/off
║➽Protect:on/off
╚═════════════╝
╔═════════════╗
╟Creator By ÑĘØ
╟SPESYTAL TO:
╟༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻
╚═════════════╝
"""
helpMessage2 ="""     [COMMAND PRIVATE]
╔═════════════╗
║➽[Protect on/off]
║➽[Gname on/off]
║➽[Spam on/off]
║➽[Qr on/off
║➽[Neo backup]
║➽[Blockinvite on/off]
║➽[Turn]
║➽[Xvedeo: ]
║➽[Protect url:on/off]
║➽[Backup:on/off]
║➽[Welcome:on/off]
║➽[Welcome: ]
║➽[Check bl]
║➽[Banlist]
║➽[Neo wl]
║➽[Neo cek]
╚═════════════╝
  Comment Bot Talk
╔═════════════╗
║➧Hehe
║➧You
║➧Sue
║➧Lol
║➧Wc
║➧Wkwk
║➧Galon
║➧Huft
║➧Please
║➧Haaa
║➧Hmmm
║➧#test
║➧Say (text) 
║➧Bot say (txt) 
║➧Ping
║➧Bot1/1 gift
║➧Bot1 up tl:
║➧Bot2 up tl:
║➧Timeline: (txt) 
║➧Mimic:on
║➧Mimic:
║➧Add: @
║➧Del: @
║➧List Target
║➧Measage:
║➧Add message:
║➧Comment:
║➧Add comment:
║➧Setlastpoint
║➧#set
║➧Point
║➧Read
║➧#Cek
║➧Readpoint
║➧Block@
║➧Clear banlist
║➧➽
╚═════════════╝
╔═════════════╗
║༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻
╚═════════════╝
"""

KAC=[cl,ki,kk,kc]
KAC2=[kc,kk,ki]
mid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
#Dmid = kx.getProfile().mid
Bots=[mid,Amid,Bmid,Cmid]
Bots=[mid,Amid,Bmid,Cmid,"u05f4feb235542b74ef4538db57f2a0bd","ua218b19150167ccab4e7be0310262678","u915a1dece700f22ba171e596e0c4bcfa","u40dca91d3a7c0c97b90fdf94ac31bf36"]
admin=["u05f4feb235542b74ef4538db57f2a0bd","ua218b19150167ccab4e7be0310262678","u915a1dece700f22ba171e596e0c4bcfa","u40dca91d3a7c0c97b90fdf94ac31bf36"]
adminMID=["u05f4feb235542b74ef4538db57f2a0bd"]
admsa = ["u05f4feb235542b74ef4538db57f2a0bd"]

#admin=["u01c38c667cf302c58ea71263325f1d83","uabccd123f6788452c8d01933883e9361","ub1423e6baa66e847ecaf50f446ad288d","u33b091bdf6669febeb66eece998c2ed0","u290ca099231a7942e1c3af0849efafe5"]
#adminMID=["u01c38c667cf302c58ea71263325f1d83"]

wait = {
    'contact':False,
    'autoJoin':False,
    'autoCancel':{"on":True, "members":1},
    'leaveRoom':False,
    'timeline':True,
    'autoAdd':False,
    "lang":"JP",
    "comment":"Auto like by: ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻",
    "commentOn":True,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "clock":False,
    "cName":"",
    "blacklist":{},
    "whitelist":{},
    "rblacklist":{},
    "rdblacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "likeOn":True,
    "welcomeOn":False,
    "qr":False,
    "purgeOn":False,
    "Backup":False,
    "protectionOn":False,
    "message":"Thanks for add me ask friends. selfbot by ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™ 🙏🙏THANKS 🙏🙏"
}

wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }
mimic = {
    "copy":True,
    "copy2":True,
    "status":True,
    "target":{}
    }

setTime = {}
setTime = wait2["setTime"]

res = {
    'num':{},
    'us':{},
    'au':{},
}

contact = cl.getProfile()
mybackup = cl.getProfile()
mybackup.displayName = contact.displayName
mybackup.statusMessage = contact.statusMessage
mybackup.pictureStatus = contact.pictureStatus

contact = ki.getProfile()
backup = ki.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

contact = kk.getProfile()
backup = kk.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

contact = kc.getProfile()
backup = kc.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def sendImageWithURL(self, to_, url):
      path = '%s/pythonLine-%i.data' % (tempfile.gettempdir(), randint(0, 9))
      r = requests.get(url, stream=True)
      if r.status_code == 200:
         with open(path, 'w') as f:
            shutil.copyfileobj(r.raw, f)
      else:
         raise Exception('Download image failure.')
      try:
         self.sendImage(to_, path)
      except:
         try:
            self.sendImage(to_, path)
         except Exception as e:
            raise e

def NOTIFIED_READ_MESSAGE(op):
    try:
        if op.param1 in wait2['readPoint']:
            Name = cl.getContact(op.param2).displayName
            if Name in wait2['readMember'][op.param1]:
                pass
            else:
                wait2['readMember'][op.param1] += "\n・" + Name
                wait2['ROM'][op.param1][op.param2] = "・" + Name
        else:
            pass
    except:
        pass

def mention(to,nama):
    aa = ""
    bb = ""
    strt = int(12)
    akh = int(12)
    nm = nama
    #print nm
    for mm in nm:
        akh = akh + 2
        aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
        strt = strt + 6
        akh = akh + 4
        bb += "◈ @c \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "「Mention」\n"+bb
    msg.contentMetadata = {'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    #print msg
    try:
         cl.sendMessage(msg)
    except Exception as error:
        print error 

def bot(op):
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))

        if op.type == 17:
          if wait["welcomeOn"] == True:
            if op.param2 in Bots:
                return
            ginfo = cl.getGroup(op.param1)
            anu = random.choice(KAC2)
            anu.sendText(op.param1, "Welcome to Group fams stay here whit me and all friend in group ➡ " + str(ginfo.name))
            anu.sendText(op.param1, "Group Owner " + str(ginfo.name) + " :\n" + ginfo.creator.displayName)

        if op.type == 11:
            if op.param3 == '1':
                if op.param1 in wait['pname']:
                    try:
                        G = cl.getGroup(op.param1)
                    except:
                        try:
                            G = ki.getGroup(op.param1)
                        except:
                            try:
                                G = kk.getGroup(op.param1)
                            except:
                                try:
                                    G = kc.getGroup(op.param1)
                                except:
                                            pass
                    G.name = wait['pro_name'][op.param1]
                    try:
                        cl.updateGroup(G)
                    except:
                        try:
                            ki.updateGroup(G)
                        except:
                            try:
                                kk.updateGroup(G)
                            except:
                                            pass
                    if op.param2 in ken:
                        pass
                    else:
                        try:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                            pass
#------------------------------------------------
        if op.type == 13:
                if op.param3 in mid:
                    if op.param2 in Amid:
                        G = ki.getGroup(op.param1)
                        G.preventJoinByTicket = False
                        ki.updateGroup(G)
                        Ticket = ki.reissueGroupTicket(op.param1)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventJoinByTicket = True
                        ki.updateGroup(G)
                        Ti = ki.reissueGroupTicket(op.param1)
                if op.param3 in Amid:
                    if op.param2 in Bmid:
                        X = kk.getGroup(op.param1)
                        X.preventJoinByTicket = False
                        kk.updateGroup(X)
                        Ti = kk.reissueGroupTicket(op.param1)
                        ki.acceptGroupInvitationByTicket(op.param1,Ti)
                        X.preventJoinByTicket = True
                        kk.updateGroup(X)
                        Ti = kk.reissueGroupTicket(op.param1)
                if op.param3 in Bmid:
                    if op.param2 in Cmid:
                        X = kc.getGroup(op.param1)
                        X.preventJoinByTicket = False
                        kc.updateGroup(X)
                        Ti = kc.reissueGroupTicket(op.param1)
                        kk.acceptGroupInvitationByTicket(op.param1,Ti)
                        X.preventJoinByTicket = True
                        kc.updateGroup(X)
                        Ti = kc.reissueGroupTicket(op.param1)
#========================================
        if op.type == 32:
            if not op.param2 in admin:
                if wait["protectionOn"] == True: 
                    try:
                        klist=[kc,cl]
                        random.choice(klist).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                        random.choice(klist).inviteIntoGroup(op.param1, [op.param3])
                    except Exception, e:
                       print e
        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)

        if op.type == 13:
            if not op.param2 in admin:
                if wait["protectionOn"] == True:  
                   klist=[ki,kc]
                   Inviter = op.param3.replace("",',')
                   InviterX = Inviter.split(",")
                   random.choice(klist).cancelGroupInvitation(op.param1, InviterX)
                   pass
            if not op.param2 in admin:
                if wait["protectionOn"] == True:
                   klist=[kc,kk,ki]
                   random.choice(klist).kickoutFromGroup(op.param1, [op.param2])
                   wait["blacklist"][op.param2] = True
                   f=codecs.open('st2__b.json','w','utf-8')
                   json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                   pass
            if not op.param2 in admin:
                if wait["protectionOn"] == True:
                   klist=[kc,ki]
                   Inviter = op.param3.replace("",',')
                   InviterX = Inviter.split(",")
                   matched_list = []
                   for tag in wait["blacklist"]:
                       matched_list+=filter(lambda str: str == tag, InviterX)
                   if matched_list == []:
                       pass
                   else:
                       random.choice(klist).cancelGroupInvitation(op.param1, matched_list)
                       pass

        if op.type == 17:
            if op.param2 in wait["blacklist"]:
               if wait["purgeOn"] == True:
                  klist=[ki,kk,kc]
                  random.choice(klist).kickoutFromGroup(op.param1, [op.param2])

        if op.type == 11:
            if not op.param2 in admin:
              if wait["qr"] == True:  
                try:
                    klist=[kc,kk]
                    G = random.choice(klist).getGroup(op.param1)
                    G.preventJoinByTicket = True
                    random.choice(klist).updateGroup(G)
                except Exception, e:
                    print e
            if not op.param2 in admin:
              if wait["protectionOn"] == True:
                 try:                    
                     klist=[kk,ki]
                     G = random.choice(klist).getGroup(op.param1)
                     G.preventJoinByTicket = True
                     random.choice(klist).updateGroup(G)
                     random.choice(klist).kickoutFromGroup(op.param1,[op.param2])
                     wait["blacklist"][op.param2] = True
                     random.choice(klist).kickoutFromGroup(op.param1,[op.param3])
                     wait["blacklist"][op.param3] = True
                     G.preventJoinByTicket = True
                     random.choice(klist).updateGroup(G)
                 except Exception, e:
                           print e
        if op.type == 11:
            if not op.param2 in Bots:
               return
            klist=[kc,kk,ki]
            anu = random.choice(klist)
            anu.sendText(op.param1,"Hi " + anu.getContact(op.param2).displayName + "\nDon't Play Code QR Link Please . . . (~_~;)")
        if op.type == 19:
                if not op.param2 in admin:
                  if wait["Backup"] == True:
                    try:
                        klist=[kk,kc]
                        random.choice(klist).inviteIntoGroup(op.param1, [op.param3])
                    except Exception, e:
                        print e
                if not op.param2 in admin:
                  if wait["protectionOn"] == True:  
                   try:
                       klist=[kc,kk,ki]
                       random.choice(klist).kickoutFromGroup(op.param1,[op.param2])
                       wait["blacklist"][op.param2] = True
                   except Exception, e:
                       print e
        if op.type == 19:              
                if mid in op.param3:
                    if op.param2 in Bots:
                        pass                   
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC2).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    klist=[kk,ki]
                    G = random.choice(klist).getGroup(op.param1)
                    G.preventJoinByTicket = False
                    random.choice(klist).updateGroup(G)
                    Ti = random.choice(klist).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)                    
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Amid in op.param3:
                    if op.param2 in Bots:
                        pass                    
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client が蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nBecause the client does not exist in the kick regulation or group.\nAdd it to the blacklist.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    klist=[kc,kk]
                    X = random.choice(klist).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(klist).updateGroup(X)
                    Ti = random.choice(klist).reissueGroupTicket(op.param1)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ki.updateGroup(G)
                    Ticket = ki.reissueGroupTicket(op.param1)                    
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Bmid in op.param3:
                    if op.param2 in Bots:
                        pass                    
                    try:
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client が蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nBecause the client does not exist in the kick regulation or group.\nAdd it to the blacklist.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    klist=[ki,kc]
                    X = random.choice(klist).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(klist).updateGroup(X)
                    Ti = random.choice(klist).reissueGroupTicket(op.param1)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kk.updateGroup(G)
                    Ticket = ki.reissueGroupTicket(op.param1)                    
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Cmid in op.param3:
                    if op.param2 in Bots:
                        pass                    
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            anu.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client が蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nBecause the client does not exist in the kick regulation or group.\nAdd it to the blacklist.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    klist=[ki,cl]
                    X = random.choice(klist).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(klist).updateGroup(X)
                    Ti = random.choice(klist).reissueGroupTicket(op.param1)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kc.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kc.updateGroup(G)
                    Ticket = kc.reissueGroupTicket(op.param1)                    
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Dmid in op.param3:
                    if op.param2 in Bots:
                        pass                    
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client が蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nBecause the client does not exist in the kick regulation or group.\nAdd it to the blacklist.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    klist=[cl,ki]
                    X = random.choice(klist).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(klist).updateGroup(X)
                    Ti = random.choice(klist).reissueGroupTicket(op.param1)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kk.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kx.updateGroup(G)
                    Ticket = kk.reissueGroupTicket(op.param1)                    
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                ki.leaveRoom(op.param1)
                kk.leaveRoom(op.param1)
                kc.leaveRoom(op.param1)
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                ki.leaveRoom(op.param1)
                kk.leaveRoom(op.param1)
                kc.leaveRoom(op.param1)
        if op.type == 26:
            msg = op.message
            if msg.toType == 0:
                msg.to = msg.from_
                if msg.from_ == "u6394d74e5c3cd8641f2dfa43c65769d8":
                    if "join:" in msg.text:
                        list_ = msg.text.split(":")
                        try:
                            cl.acceptGroupInvitationByTicket(list_[1],list_[2])
                            ki.acceptGroupInvitationByTicket(list_[1],list_[2])
                            kk.acceptGroupInvitationByTicket(list_[1],list_[2])
                            kc.acceptGroupInvitationByTicket(list_[1],list_[2])
                            X = cl.getGroup(list_[1])
                            X = ki.getGroup(list_[1])
                            X = kk.getGroup(list_[1])
                            X = kc.getGroup(list_[1])
                            X.preventJoinByTicket = True
                            cl.updateGroup(X)
                            ki.updateGroup(X)
                            kk.updateGroup(X)
                            kc.updateGroup(X)
                        except:
                            cl.sendText(msg.to,"error")
            if msg.toType == 1:
                if wait["leaveRoom"] == True:
                    cl.leaveRoom(msg.to)
                    ki.leaveRoom(msg.to)
                    kk.leaveRoom(msg.to)
                    kc.leaveRoom(msg.to)
            if msg.contentType == 16:
                url = msg.contentMetadata("line://home/post?userMid="+mid+"&postId="+"new_post")
                cl.like(url[25:58], url[66:], likeType=1001)
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
               if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendText(msg.to,"already add the acount whitelist . . .")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendText(msg.to,"decided not to comment")
                        
               elif wait["dblack"] == True:
                   if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted acount fom the black list.  . .")
                        wait["dblack"] = False
                        
                   else:
                        wait["dblack"] = False
                        cl.sendText(msg.to,"It is not in the black list")
               elif wait["wblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"already")
                        wait["wblacklist"] = False
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        cl.sendText(msg.to,"aded")
                        
               elif wait["dblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Deleted")
                        
                        wait["dblacklist"] = False
                        
                   else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"It is not in the black list")
#-------------REPEAT_BAN-------------
               elif wait["Ban:repeat"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"Already in Blacklis now.  . .")
                        wait["rblacklist"] = True
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["rblacklist"] = True
                        cl.sendText(msg.to,"Succes add the  Black list . . .")

               elif wait["rdblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Succes add the blacklist . . .")

                        wait["rdblacklist"] = True

                   else:
                        wait["rdblacklist"] = True
                        cl.sendText(msg.to,"It is not in the black list . . .")
#-------------REPEAT_BAN-------------
               elif wait["contact"] == True:
                    msg.contentType = 0
                    #cl.sendText(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"➽ Profile Name :\n" + msg.contentMetadata["displayName"] + "\n\n➽ Mid :\n" + msg.contentMetadata["mid"] + "\n\n➽ Status Message :\n" + contact.statusMessage + "\n\n➽ Pict Status :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n➽ Cover Status :\n" + str(cu) + "\n\n     ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"➽ Profile Name :\n" + contact.displayName + "\n\n➽ Mid :\n" + msg.contentMetadata["mid"] + "\n\n➽ Status Mesage:\n" + contact.statusMessage + "\n\n➽ Pict Status :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n➽ Cover Status :\n" + str(cu) + "\n\n   ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "Post URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "URL→\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)

            elif msg.text in ["Help","Commands"]:
                print "\nHelp pick up..."
                cl.sendText(msg.to, helpMessage + "")
            elif msg.text in ["Help2","Key"]:
                print "\nHelp pick up..."
                cl.sendText(msg.to, helpMessage2 + "")

            elif ("Gn: " in msg.text):
                if msg.toType == 2:
                    klist=[kc,kk,ki,cl]
                    anu = random.choice(klist)
                    G = anu.getGroup(msg.to)
                    G.name = msg.text.replace("Gn: ","Group namame: ")
                    anu.updateGroup(G)
                else:
                    anu.sendText(msg.to,"Not for use less than group")
            elif "Kick: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Kick: ","")
                    klist=[kc,kk,ki,cl]
                    kicker = random.choice(klist)
                    kicker.kickoutFromGroup(msg.to,[midd])

            elif "Invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Invite: ","")
                    cl.findAndAddContactsByMid(midd)
                    cl.inviteIntoGroup(msg.to,[midd])
            elif "Bot1 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Bot1 invite: ","Neo1 invite: ")
                    ki.findAndAddContactsByMid(midd)
                    ki.inviteIntoGroup(msg.to,[midd])
            elif "Bot2 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Bot2 invite: ","Neo2 invite: ")
                    kk.findAndAddContactsByMid(midd)
                    kk.inviteIntoGroup(msg.to,[midd])
            elif "Bot3 invite: " in msg.text:
                if msg.toType == 2:
                    midd = msg.text.replace("Bot3 invite: ","Neo3 invite: ")
                    kc.findAndAddContactsByMid(midd)
                    kc.inviteIntoGroup(msg.to,[midd])
#---------------------------------------------
            elif msg.text in ["Update name: "]:
				if msg.from_ in admin:
					string = msg.text.replace("Update name: ")
					if len(string.decode('utf-8')) <= 20:
						profile = cl.getProfile()
						profile.displayName = string
						cl.updateProfile(profile)
						cl.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Neo1 update name: "]:
				if msg.from_ in admin:
					string = msg.text.replace("Neo1 update name: ","")
					if len(string.decode('utf-8')) <= 20:
						profile_B = ki.getProfile()
						profile_B.displayName = string
						ki.updateProfile(profile_B)
						ki.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Neo2 update name: "]:
				if msg.from_ in admin:
					string = msg.text.replace("Neo2 update name: ","")
					if len(string.decode('utf-8')) <= 20:
						profile_B = kk.getProfile()
						profile_B.displayName = string
						kk.updateProfile(profile_B)
						kk.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Neo3 update name: "]:
				if msg.from_ in admin:
					string = msg.text.replace("Neo3 update name: ","")
					if len(string.decode('utf-8')) <= 20:
						profile_B = kc.getProfile()
						profile_B.displayName = string
						kc.updateProfile(profile_B)
						kc.sendText(msg.to,"name " + string + " done")

#------------------------------------------------
            elif "K1 upstatus: " in msg.text:
                string = msg.text.replace("K1 upstatus: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile_B = ki.getProfile()
                    profile_B.statusMessage = string
                    ki.updateProfile(profile_B)
                    ki.sendText(msg.to,"display message " + string + " done")
            elif "K2 upstatus: " in msg.text:
                string = msg.text.replace("K2 upstatus: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile_C = kk.getProfile()
                    profile_C.statusMessage = string
                    kk.updateProfile(profile_C)
                    kk.sendText(msg.to,"display message " + string + " done")
            elif "K3 upstatus: " in msg.text:
                string = msg.text.replace("K3 upstatus: ","")
                if len(string.decode('utf-8')) <= 500:
                    profile_C = kc.getProfile()
                    profile_C.statusMessage = string
                    kc.updateProfile(profile_C)
                    kc.sendText(msg.to,"display message " + string + " done")

#-----------------------------------------------------
            elif "Me" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)
            elif "Mid" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                cl.sendMessage(msg)
            elif "Bot1" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                ki.sendMessage(msg)
            elif "Bot2" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                kk.sendMessage(msg)
            elif "Bot3" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                kc.sendMessage(msg)
            elif "All mid" == msg.text:
                msg.contactType = 13
                msg.contactMetadata = {'mid': Allmid}
                cl.sendMessage(msg)
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
#                kx.sendMessage(msg)
            elif msg.text in ["Gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '2'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift1"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'af2d64ad-ccd2-49fa-8fb4-25ae2836a369',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '5'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift2"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'f44b6a1a-bdfa-47f7-a839-e7938eb71aac',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '7'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Gift3"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': '89131c1a-e549-4bd5-9e60-e24de0d2e252',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '10'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["Bot1 gift","Neo1 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}
                msg.text = None
                ki.sendMessage(msg)
            elif msg.text in ["Bot2 gift","Neo2 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '8'}
                msg.text = None
                kk.sendMessage(msg)
            elif msg.text in ["Bot3 gift","Neo3 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '9'}
                msg.text = None
                kc.sendMessage(msg)
            elif msg.text in ["Bot4 gift","Neo4 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '4'}
                msg.text = None
                kx.sendMessage(msg)
            elif msg.text in ["Allgift","All gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '12'}
                msg.text = None
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
#                kx.sendMessage(msg)

            elif msg.text in ["Batal","Cancel","Cancel invites","Clean invites"]:
                if msg.toType == 2:
                    G = cl.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"No one is inviting . . .")
                        else:
                            cl.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot cancel","Neo clean invites"]:
                if msg.toType == 2:
                    neo = random.choice(KAC2)
                    G = cl.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        neo.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            neo.sendText(msg.to,"No one is inviting . . .")
                        else:
                            neo.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group")
                    else:
                        anu.sendText(msg.to,"Not for use less than group")

            elif msg.text in ["Link on","Ourl","Qron"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        a
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"URL is ready open . . .")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Slink on","Neo qron"]:
                if msg.toType == 2:
                    klist=[kc,kk,ki]
                    anu = random.choice(klist)
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    anu.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done")
                    else:
                        anu.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group")
                    else:
                        anu.sendText(msg.to,"Not for use less than group")

            elif msg.text in ["Link off","Qroff"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"Qr is already close . . .")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Slink off","Neo qroff"]:
                if msg.toType == 2:
                    klist=[kc,kk,ki]
                    anu = random.choice(klist)
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    anu.updateGroup(X)
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Done")
                    else:
                        anu.sendText(msg.to,"Already close . . .")
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group")
                    else:
                        anu.sendText(msg.to,"Not for use less than group")

            elif msg.text == "Ginfo":
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "[Error]"
                    if wait["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                        if ginfo.preventJoinByTicket == True:
                            u = "Close"
                        else:
                            u = "Open"
                        cl.sendText(msg.to,"⎆ Group Name :\n" + str(ginfo.name) + "\n\n⎆Group ID :\n" + msg.to + "\n\n Group Creator :\n" + gCreator + "\n\n Group Picture :\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "\n\n[Group Members] : [" + str(len(ginfo.members)) + "] user\n[Pending Members] : [" + sinvitee + "] user\n\n QR Status : " + u + "\n\n    ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻")
                    else:
                        cl.sendText(msg.to,"⎆ Group Name :\n" + str(ginfo.name) + "\n\n⎆ Group ID :\n" + msg.to + "\n\n Group Creator :\n" + gCreator + "\n\n Group Picture :\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Glist","Mygroups"]:
                gs = cl.getGroupIdsJoined()
                L = "❝Groups List❞\n"
                num=1
                for i in gs:
                    L += "\n%i. %s " % (num, cl.getGroup(i).name + " ➡ " + str(len (cl.getGroup(i).members)))
                    num=(num+1)
                L += "\n\n➽ Total Groups : [ %i ]" % len(gs)
                cl.sendText(msg.to, L + "")
            elif msg.text in ["All gid","Allgid"]:
                gid1 = cl.getGroupIdsJoined()
                gid2 = ki.getGroupIdsJoined()
                gid3 = kk.getGroupIdsJoined()
                gid4 = kc.getGroupIdsJoined()
                G1 = "☆ Group ID ☆\n"
                G2 = "☆ Group ID ☆\n"
                G3 = "☆ Group ID ☆\n"
                G4 = "⭐ Group ID ☆\n"
                for i in gid1:
                    G1 += "⭐ %s\n%s\n" % (cl.getGroup(i).name, i)
                for i in gid2:
                    G2 += "⭐ %s\n%s\n" % (ki.getGroup(i).name, i)
                for i in gid3:
                    G3 += "⭐ %s\n%s\n" % (kk.getGroup(i).name, i)
                for i in gid4:
                    G4 += "⭐ %s\n%s\n" % (kc.getGroup(i).name, i)
                cl.sendText(msg.to, G1 + "\n\n⋙ Groups : [ " + str(len(gid1)) + " ]")
                ki.sendText(msg.to, G2 + "\n\n⋙ Groups : [ " + str(len(gid2)) + " ]")
                kk.sendText(msg.to, G3 + "\n\n⋙ Groups : [ " + str(len(gid3)) + " ]")
                kc.sendText(msg.to, G4 + "\n\n⋙ Groups : [ " + str(len(gid4)) + " ]")
                
            elif msg.text in ["Bot1glist"]:
                gs = ki.getGroupIdsJoined()
                L = "Groups List \n"
                for i in gs:
                    L += "╟ %s \n" % (ki.getGroup(i).name + " | [ " + str(len (ki.getGroup(i).members)) + " ]")
                ki.sendText(msg.to, L + "\n Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Bot2glist"]:
                gs = kk.getGroupIdsJoined()
                L = " Groups List \n"
                for i in gs:
                    L += "╟ %s \n" % (kk.getGroup(i).name + " | [ " + str(len (kk.getGroup(i).members)) + " ]")
                kk.sendText(msg.to, L + "\n☫ Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Bot3glist"]:
                gs = kc.getGroupIdsJoined()
                L = " Groups List \n"
                for i in gs:
                    L += "║ %s \n" % (kc.getGroup(i).name + " | [ " + str(len (kc.getGroup(i).members)) + " ]")
                kc.sendText(msg.to, L + "\n✖ Total Groups : [ " + str(len(gs)) +" ]")
            elif msg.text in ["Allglist"]:
                gs1 = cl.getGroupIdsJoined()
                gs2 = ki.getGroupIdsJoined()
                gs3 = kk.getGroupIdsJoined()
                gs4 = kc.getGroupIdsJoined()
                L1 = " Groups List \n"
                L2 = " Groups List \n"
                L3 = " Groups List \n"
                L4 = " Groups List \n"
                for i in gs1:
                    L1 += "║ %s \n" % (cl.getGroup(i).name + " | [ " + str(len (cl.getGroup(i).members)) + " ]")
                for i in gs2:
                    L2 += "║ %s \n" % (ki.getGroup(i).name + " | [ " + str(len (ki.getGroup(i).members)) + " ]")
                for i in gs3:
                    L3 += "║ %s \n" % (kk.getGroup(i).name + " | [ " + str(len (kk.getGroup(i).members)) + " ]")
                for i in gs4:
                    L4 += "║ %s \n" % (kc.getGroup(i).name + " | [ " + str(len (kc.getGroup(i).members)) + " ]")
                cl.sendText(msg.to, L1 + "\n Total Groups : [ " + str(len(gs1)) +" ]")
                ki.sendText(msg.to, L2 + "\n Total Groups : [ " + str(len(gs2)) +" ]")
                kk.sendText(msg.to, L3 + "\n Total Groups : [ " + str(len(gs3)) +" ]")
                kc.sendText(msg.to, L4 + "\n Total Groups : [ " + str(len(gs4)) +" ]")

            elif "Id" == msg.text:
                key = msg.to
                cl.sendText(msg.to, key)
            elif "Mid mid" == msg.text:
                cl.sendText(msg.to,mid)
                ki.sendText(msg.to,Amid)
                kk.sendText(msg.to,Bmid)
                kc.sendText(msg.to,Cmid)
            elif "Bot mid" == msg.text:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                cl.sendMessage(msg)

            elif "Wkwk" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "100",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Hehe" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "10",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Galon" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "9",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "You" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "7",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Sue" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "105",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Huft" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "104",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Please" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "4",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Haaa" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "3",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Lol" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "110",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Hmmm" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "101",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
            elif "Wc" == msg.text:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "247",
                                     "STKPKGID": "3",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
#============================================
            elif "Say " in msg.text:
				bctxt = msg.text.replace("Say ","")
				ki.sendText(msg.to,(bctxt))
				kk.sendText(msg.to,(bctxt))
				kc.sendText(msg.to,(bctxt))
            elif "Bot say " in msg.text:
				saytxt = msg.text.replace("Bot say ","")
				klist=[kc,kk,ki]
				anu = random.choice(klist)
				anu.sendText(msg.to,(saytxt))
            elif msg.text in ["Neo say hi"]:
                ki.sendText(msg.to,"Hi buddy . . .")
                kk.sendText(msg.to,"Hi buddy . . .")
                kc.sendText(msg.to,"Hi Everybuddy . . .")
            elif msg.text in ["Ping"]:
                ki.sendText(msg.to,"PONG . . .")
                kk.sendText(msg.to,"PONG . . .")
                kc.sendText(msg.to,"PONG . . .")
            elif msg.text in ["#welcome"]:
                ki.sendText(msg.to,"Selamat datang kakak keceh . . .")
                kk.sendText(msg.to,"No baper no ribet yang penting kita happy . . .")
                kc.sendText(msg.to,"Semoga betah ya kak . . . 😊😘😘")
            elif "Respon" in msg.text:
                s1 = ki.getProfile()
                s2 = kk.getProfile()
                s3 = kc.getProfile()
                s4 = kx.getProfile()
                ki.sendText(msg.to, s.displayName)
                kk.sendText(msg.to, s2.displayName)
                kc.sendText(msg.to, s3.displayName)
 #               kx.sendText(msg.to, s4.displayName)
#-----------------------------------------------
#            elif msg.text in "Creator":
#                msg.contentType = 13
#                msg.contentMetadata = {'mid': "u05f4feb235542b74ef4538db57f2a0bd"}
#                cl. sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
#                cl. sendText(msg.to, "✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
#                cl. sendText(msg.to, "And . . .")
#                cl. sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
#                cl.sendMessage(msg)
            elif msg.text in "Bot1 creator":
                msg.contentType = 13
                msg.contentMetadata = {'mid': "u05f4feb235542b74ef4538db57f2a0bd"}
                ki.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                ki.sendText(msg.to, "✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
                ki.sendText(msg.to, "And . . .")
                ki.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                ki.sendMessage(msg)
            elif msg.text in "Bot2 creator":
                msg.contentType = 13
                msg.contentMetadata = {'mid': "u05f4feb235542b74ef4538db57f2a0bd"}
                kk.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                kk.sendText(msg.to, "✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
                kk.sendText(msg.to, "And . . .")
                kk.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                kk.sendMessage(msg)

            elif msg.text in "Bot3 creator":
                msg.contentType = 13
                msg.contentMetadata = {'mid': "u05f4feb235542b74ef4538db57f2a0bd"}
                kc.sendText(msg.to, "Selfbot Created By ÑĘØ.  . .")
                kc.sendText(msg.to, "✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
                kc.sendText(msg.to, "And . . .")
                kc.sendText(msg.to, "༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻")
                kc.sendMessage(msg)

 #============================================
            elif "Broadcast: " in msg.text:
					bctxt = msg.text.replace("Broadcast: ","")
					contact = cl.getAllContactIds()
					for cbc in contact:
						cl.sendText(cbc,(bctxt))
						ki.sendText(cbs,(bctxt))
						kk.sendText(cbs,(bctxt))
						kc.sendTrxt(cbs,(bctxt))
            elif "Pmcast: " in msg.text:
					bctxt = msg.text.replace("Pmcast: ", "")
					contact = cl.getAllContactIds()
					for cbc in contact:
						cl.sendText(cbc,(bctxt))
            elif "Bot1 pmcast: " in msg.text:
					bctxt = msg.text.replace("Bot1 pmcast: ","Neo1 pmcast: ")
					contact = ki.getAllContactIds()
					for cbc in contact:
						ki.sendText(cbc,(bctxt))
            elif "Bot2 pmcast: " in msg.text:
					bctxt = msg.text.replace("Bot2 pmcast: ","Neo2 pmcast: ")
					contact = kk.getAllContactIds()
					for cbc in contact:
						kk.sendText(cbc,(bctxt))
            elif "Bot3 pmcast: " in msg.text:
					bctxt = msg.text.replace("Bot3 pmcast: ","Neo3 pmcast: ")
					contact = kc.getAllContactIds()
					for cbc in contact:
						kc.sendText(cbc,(bctxt))
            elif "Groupcast: " in msg.text:
					bctxt = msg.text.replace("Groupcast: ","Gbc: ")
					group = cl.getGroupIdsJoined()
					for gbc in group:
						cl.sendText(gbc,(bctxt))
						ki.sendText(gbc,(bctxt))
						kk.sendText(gbc,(bctxt))
						kc.sendText(gbc,(bctxt))
            elif "Mygroupcast: " in msg.text:
					bctxt = msg.text.replace("Mygroupcast: ","")
					group = cl.getGroupIdsJoined()
					for gbc in group:
						cl.sendText(gbc,(bctxt))
            elif "Bot1 groupcast: " in msg.text:
					bctxt = msg.text.replace("Bot1 groupcast: ","Neo1 groupcast: ")
					group = ki.getGroupIdsJoined()
					for gbc in group:
						ki.sendText(gbc,(bctxt))
            elif "Bot2 groupcast: " in msg.text:
					bctxt = msg.text.replace("Bot2 groupcast: ","Neo2 groupcast: ")
					group = kk.getGroupIdsJoined()
					for gbc in group:
						kk.sendText(gbc,(bctxt))
            elif "Bot3 groupcast: " in msg.text:
					bctxt = msg.text.replace("Bot3 groupcast: ","Neo3 groupcast: ")
					group = kc.getGroupIdsJoined()
					for gbc in group:
						kc.sendText(gbc,(bctxt))
#=============================================
            elif msg.text in ["Gcreator","Gc"]:
                if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)
#=========================================================
            elif "Tl: " in msg.text:
                tl_text = msg.text.replace("Tl: ","Timeline: ")
                cl.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+cl.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
            elif "Neo1 tl: " in msg.text:
                tl_text = msg.text.replace("Neo1 tl: ","Neo1 timeline: ")
                ki.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+ki.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])

            elif "Neo2 tl: " in msg.text:
                tl_text = msg.text.replace("Neo2 tl: ","Neo2 timeline: ")
                kk.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+kk.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
            elif "Neo3 tl: " in msg.text:
                tl_text = msg.text.replace("Neo3 tl: ","Neo3 timeline: ")
                kc.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+kc.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])

 #-------------------------------------------------------------------------
            elif msg.from_ in mimic["target"] and mimic["status"] == True and mimic["target"][msg.from_] == True:
            	text = msg.text
            	if text is not None:
            		cl.sendText(msg.to,text)
            	else:
            		if msg.contentType == 7:
            			msg.contentType = 7
            			msg.text = None
            			msg.contentMetadata = {
            							 	 "STKID": "6",
            							 	 "STKPKGID": "1",
            							 	 "STKVER": "100" }
            			cl.sendMessage(msg)
            		elif msg.contentType == 13:
            			msg.contentType = 13
            			msg.contentMetadata = {'mid': msg.contentMetadata["mid"]}
            			cl.sendMessage(msg)
            elif "Mimic:" in msg.text:
            	if msg.from_ in admin:
            		cmd = msg.text.replace("Mimic:","Mimic:on")
            		if cmd == "on":
            			if mimic["status"] == False:
            				mimic["status"] = True
            				cl.sendText(msg.to,"Mimic on")
            			else:
            				cl.sendText(msg.to,"Mimic already on")
            		elif cmd == "off":
            			if mimic["status"] == True:
            				mimic["status"] = False
            				cl.sendText(msg.to,"Mimic off")
            			else:
            				cl.sendText(msg.to,"Mimic already off")
            		elif "add:" in cmd:
            			target0 = msg.text.replace("add:","Mimic add")
            			target1 = target0.lstrip()
            			target2 = target1.replace("@","")
            			target3 = target2.rstrip()
            			_name = target3
            			gInfo = cl.getGroup(msg.to)
            			targets = []
            			for a in gInfo.members:
            				if _name == a.displayName:
            					targets.append(a.mid)
            			if targets == []:
            				cl.sendText(msg.to,"No targets")
            			else:
            				for target in targets:
            					try:
            						mimic["target"][target] = True
            						cl.sendText(msg.to,"Success added target")
            						#cl.sendMessageWithMention(msg.to,target)
            						break
            					except:
            						cl.sendText(msg.to,"Failed")
            						break
            		elif "Del:" in cmd:
            			target0 = msg.text.replace("Mimic: ","Del: ","Mimicdel ")
            			target1 = target0.lstrip()
            			target2 = target1.replace("@","")
            			target3 = target2.rstrip()
            			_name = target3
            			gInfo = cl.getGroup(msg.to)
            			targets = []
            			for a in gInfo.members:
            				if _name == a.displayName:
            					targets.append(a.mid)
            			if targets == []:
            				cl.sendText(msg.to,"No targets")
            			else:
            				for target in targets:
            					try:
            						del mimic["target"][target]
            						cl.sendText(msg.to,"Success deleted target")
            						#cl.sendMessageWithMention(msg.to,target)
            						break
            					except:
            						cl.sendText(msg.to,"Failed!")
            						break
            		elif cmd == "ListTarget":
            			if mimic["target"] == {}:
            				cl.sendText(msg.to,"No target")
                    	else:
                    		lst = "<<Lit Target>>"
                    		total = len(mimic["target"])
                    		for a in mimic["target"]:
                				if mimic["target"][a] == True:
                					stat = "On"
                				else:
                					stat = "Off"
                				lst += "\n->" + cl.getContact(mi_d).displayName + " | " + stat
                                cl.sendText(msg.to,lst + "\nTotal:" + total)
#-----------------------------------------------
            elif ("Copy @" in msg.text):
                   print "[COPY] Ok"
                   _name = msg.text.replace("Copy @","Clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       cl.sendText(msg.to, "Not found . . .")
                   else:
                       for target in targets:
                            try:
                               cl.cloneContactProfile(target)
                               cl.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print e
            elif ("Bot1 copy @" in msg.text):
                   print "[S1_COPY] Ok"
                   _name = msg.text.replace("Bot1 copy @","Neo1 clone:on @","Bot1 clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = ki.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       ki.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               ki.cloneContactProfile(target)
                               ki.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print e
            elif ("Bot2 copy @" in msg.text):
                   print "[S2_COPY] Ok"
                   _name = msg.text.replace("Bot2 copy @","Neo2 copy @","Neo2 clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = kk.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       kk.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               kk.cloneContactProfile(target)
                               kk.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print e
            elif ("Bot3 copy @" in msg.text):
                   print "[S3_COPY] Ok"
                   _name = msg.text.replace("Bot3 copy @","Neo3 copy @ ","Neo3 clone:on @")
                   _nametarget = _name.rstrip('  ')
                   gs = kc.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       kc.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               kc.cloneContactProfile(target)
                               kc.sendText(msg.to, "Succes Copy Profile . . .")
                            except Exception as e:
                                print e

            elif msg.text in ["Protect:on","Protect on"]:
                if wait["protectionOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect is already on . . .")
                    else:
                        cl.sendText(msg.to,"Protection On")
                else:
                    wait["protectionOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection On")
                    else:
                        cl.sendText(msg.to,"Already on")
            elif msg.text in ["Pqr:off","Pqr off","Qrprotect:off"]:
                if wait["qr"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Qr protect is Already off . . .")
                    else:
                        cl.sendText(msg.to,"Protection QR Off")
                else:
                    wait["qr"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection QR Off")
                    else:
                        cl.sendText(msg.to,"Already off")
            elif msg.text in ["Pqr:on","Pqr on","Qrprotect:on"]:
                if wait["qr"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"protect qr is already on . . .")
                    else:
                        cl.sendText(msg.to,"Protection QR On")
                else:
                    wait["qr"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection QR On")
                    else:
                        cl.sendText(msg.to,"Already on")
            elif msg.text in ["Protect:off","Protect off"]:
                if wait["protectionOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection id already off . .  ")
                    else:
                        cl.sendText(msg.to,"Protection Off")
                else:
                    wait["protectionOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protection Off")
                    else:
                        cl.sendText(msg.to,"Already off")
            elif "Cn: " in msg.text:
                string = msg.text.replace("Cn: ","Rname: ","Myname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Name " + string + " done")
            elif "S1 rename: " in msg.text:
                string = msg.text.replace("S1 rename: ","Neo1 rname: ","Bot1 rname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = ki.getProfile()
                    profile_B.displayName = string
                    ki.updateProfile(profile_B)
                    ki.sendText(msg.to,"Name " + string + " done")
            elif "S2 rename: " in msg.text:
                string = msg.text.replace("S2 rename: ","Neo2 rname: ","Bot2 rname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = kk.getProfile()
                    profile_B.displayName = string
                    kk.updateProfile(profile_B)
                    kk.sendText(msg.to,"Name " + string + " done")
            elif "S3 rename: " in msg.text:
                string = msg.text.replace("S3 rename: ","Neo3 rname: ","Bot3 rname: ")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = kc.getProfile()
                    profile_B.displayName = string
                    kc.updateProfile(profile_B)
                    kc.sendText(msg.to,"Name " + string + " done")
            elif "S4 rename: " in msg.text:
                string = msg.text.replace("S4 rename: ","")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = kx.getProfile()
                    profile_B.displayName = string
                    kx.updateProfile(profile_B)
                    kx.sendText(msg.to,"Name " + string + " done")

            elif "Check" in msg.text:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                mi = cl.getContact(key1)
                cl. sendText(msg.to, "Waiting . . .")
                cl. sendText(msg.to, "Already checking your acount.  . . .")
                cl. sendText(msg.to,"[Your MID]✅   \n\n" + key1)
                cl. sendText(msg.to, "Sucsess checking. . . .")
            elif ("Cek" in msg.text):
                   key = eval(msg.contentMetadata["MENTION"])
                   key1 = key["MENTIONEES"][0]["M"]
                   mi = cl.getContact(key1)
                   cl.sendText(msg.to,"[Mid]    \n\n" +  key1)
            elif "Umid: " in msg.text:
                mmid = msg.text.replace("Umid: ","Kmid: ")
                msg.contentType = 13
                msg.contentMetadata = {"mid":mmid}
                cl.sendMessage(msg)

            elif msg.text in ["K on","Contact:on","Contact on","K:on"]:
                if wait["contact"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Contact is already on . . .")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["contact"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["K:off","Contact:off","Contact off","K off"]:
                if wait["contact"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Contact is already off . . .")
                    else:
                        cl.sendText(msg.to,"done ")
                else:
                    wait["contact"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")

            elif msg.text in ["Auto join on","Join on","Join:on","Auto join:on"]:
                if wait["autoJoin"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoJoin"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Join off","Auto join off","Auto join:off","Join:off"]:
                if wait["autoJoin"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto join is already off . . .")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoJoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")

            elif "Gcancel " in msg.text:
                try:
                    strnum = msg.text.replace("Gcancel ","Neo Gcancel")
                    if strnum == "off":
                        wait["autoCancel"]["on"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Invitation refused turned off\nTo turn on please specify the number of people and send")
                        else:
                            cl.sendText(msg.to,"关了邀请拒绝。要时开请指定人数发送")
                    else:
                        num =  int(strnum)
                        wait["autoCancel"]["on"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,strnum + " The group of people and below decided to automatically refuse invitation")
                        else:
                            cl.sendText(msg.to,strnum + "使人以下的小组用自动邀请拒绝")
                except:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Value is wrong")
                    else:
                        cl.sendText(msg.to,"Bizarre ratings")

            elif msg.text in ["Leave:on","Auto leave on","Auto leave:on","Leave on"]:
                if wait["leaveRoom"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto leave is already on . . .")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["leaveRoom"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"要了开。")
            elif msg.text in ["Leave:off","Auto leave off","Auto leave:off","Leave off"]:
                if wait["leaveRoom"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto leave is already off . . .")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["leaveRoom"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"already")

            elif msg.text in ["共有:オン","Share on","Share:on"]:
                if wait["timeline"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Timeline share is already on . . .")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["timeline"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"要了开。")
            elif msg.text in ["共有:オフ","Share off","Share:off"]:
                if wait["timeline"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Timeline share is already off . . .")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["timeline"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"要了关断。")

            elif msg.text in ["Auto like on","Like on","Auto like:on"]:
                if wait["likeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto like is already on now . . .")
                else:
                    wait["likeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto Like Turn On")
            elif msg.text in ["Auto like off","Like off","Auto like:off"]:
                if wait["likeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto like is already off . . .")
                else:
                    wait["likeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto Like Turn off")

            elif msg.text in ["Welcome on","Welcome:on","Wc on","Wc:on"]:
                if wait["welcomeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Messages auto welcome is already on . . .")
                else:
                    wait["welcomeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome Message Turn on")
            elif msg.text in ["Welcome off","Welcome:off","Wc off","Wc:off"]:
                if wait["welcomeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome messages is already off . . .")
                else:
                    wait["welcomeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Welcome Message Turn off")

            elif msg.text in ["Auto purge on","Auto purge:on","Purge:on","Purge on"]:
                if wait["purgeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Purge swiching  already on . . .")
                else:
                    wait["purgeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"「Auto purge on」\n\n °Warning!!!\n °Don't invite member from Blacklist users")
            elif msg.text in ["Auto purge ff","Auto purge:off","Purge:off","Purge off"]:
                if wait["purgeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Purge swiching already off . . .")
                else:
                    wait["purgeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto purge is turned off")

            elif msg.text in ["Stat","Status","Set"]:
            	print "Setting pick up..."
                md = "―╍═≡≣SETTINGS≣≡═╍―\n\n╔═════════════╗\n"
                if wait["contact"] == True: md+="╟ Contact : on\n"
                else: md+="╟ Contact : off\n"
                if wait["autoJoin"] == True: md+="╟ Auto join : on\n"
                else: md +="╟ Auto join : off\n"
                if wait["autoCancel"]["on"] == True:md+="╟ Group cancel :" + str(wait["autoCancel"]["members"]) + "\n"
                else: md+= "╟ Group cancel : off\n"
                if wait["leaveRoom"] == True: md+="╟ Auto leave : on\n"
                else: md+="╟ Auto leave : off\n"
                if wait["timeline"] == True: md+="╟ Share : on\n"
                else:md+="╟ Share : off\n"
                if wait["clock"] == True: md+="╟ Clock Name : on\n"
                else:md+="╟ Clock Name : off\n"
                if wait["autoAdd"] == True: md+="║ Auto add : on\n"
                else:md+="╟ Auto add : off\n"
                if wait["welcomeOn"] == True: md+="╟ Message : on\n"
                else:md+="╟ Message : off\n"
                if wait["likeOn"] == True: md+="╟ Auto Like : on\n"
                else:md+="╟ Auto Like : off\n"
                if wait["Backup"] == True: md+="╟ Backup : on\n"
                else:md+="╟ Backup : off\n"
                if wait["purgeOn"] == True: md+="╟ Auto purge : on\n"
                else:md+="╟ Auto purge : off\n"
                if wait["qr"] == True: md+="╟ Protect Link : on\n"
                else:md+="╟ Protect Link : off\n"
                if wait["protectionOn"] == True: md+="╟ Protection : on\n╚═════════════╝\n\n╔═════════════╗\n   ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n╚═════════════╝"
                else:md+="╟ Protection : off\n╚═════════════╝\n\n╔═════════════╗\n   ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n╚═════════════╝"
                cl.sendText(msg.to,md)
#========================================
            elif msg.text in ["Backup:on","Backup on"]:
                if wait["Backup"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backuping member is already on . . .")
                    else:
                        cl.sendText(msg.to,"Backup On")
                else:
                    wait["Backup"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backup On")
                    else:
                        cl.sendText(msg.to,"Backuping member is lready on . . .")
            elif msg.text in ["Backup:off","Backup off"]:
                if wait["Backup"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backups already swiching  off . . .")
                    else:
                        cl.sendText(msg.to,"Backup Off")
                else:
                    wait["Backup"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Backup Off")
                    else:
                        cl.sendText(msg.to,"Backups is already swiching off . . .")
            elif msg.text in ["Rgroups"]:
                gid = cl.getGroupIdsInvited()
                for i in gid:
                    cl.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"All invitations have been rejected . . .")
                else:
                    cl.sendText(msg.to,"拒绝了全部的邀请。")
            elif msg.text in ["S1 rgroups","Bot1 rgroups","Neo1 rgroups"]:
                gid = ki.getGroupIdsInvited()
                for i in gid:
                    ki.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    ki.sendText(msg.to,"All invitations is clean")
                else:
                    ki.sendText(msg.to,"拒绝了全部的邀请。")
            elif msg.text in ["S2 rgroups","Bot2 rgroups","Neo2 rgruoups"]:
                gid = kk.getGroupIdsInvited()
                for i in gid:
                    kk.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    kk.sendText(msg.to,"All invitations is clean . . .")
                else:
                    kk.sendText(msg.to,"拒绝了全部的邀请。")
            elif msg.text in ["Add:on","Auto add on","Auto add:on","Add on"]:
                if wait["autoAdd"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto add is already on . . .")
                    else:
                        cl.sendText(msg.to,"Done")
                else:
                    wait["autoAdd"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"Already on")
            elif msg.text in ["Add:off","Auto add off","Auto add:off","Add off"]:
                if wait["autoAdd"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Auto add is already off . . .")
                    else:
                        cl.sendText(msg.to,"Done")
                else:
                    wait["autoAdd"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"Already off")
#========================================
            elif "Message: " in msg.text:
                wait["message"] = msg.text.replace("Message: ","")
                cl.sendText(msg.to,"message changed . . .")
            elif "Add message: " in msg.text:
                wait["message"] = msg.text.replace("Add message: ","")
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message changed . . .")
                else:
                    cl.sendText(msg.to,"done。")
            elif msg.text in ["Message"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message change to\n\n" + wait["message"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as follows。\n\n" + wait["message"])
            elif "Comment: " in msg.text:
                c = msg.text.replace("Comment: ","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed . . .")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
            elif "Add comment: " in msg.text:
                c = msg.text.replace("Add comment: ","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed . . .")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)

            elif msg.text in ["Comment on","Comment:on"]:
                if wait["commentOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"Auto command is already on . . .")
                else:
                    wait["commentOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"Already on")
            elif msg.text in ["Comment off","Comment:off"]:
                if wait["commentOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"Auto command is already off . . .")
                else:
                    wait["commentOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done")
                    else:
                        cl.sendText(msg.to,"Already off")
            elif msg.text in ["Comment"]:
                cl.sendText(msg.to,"message changed to\n\n" + str(wait["comment"]))
            elif msg.text in ["Gurl"]:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.preventJoinByTicket == True:
                        X.preventJoinByTicket = False
                        cl.updateGroup(X)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot gurl"]:
                if msg.toType == 2:
                    anu = random.choice(KAC2)
                    X = cl.getGroup(msg.to)
                    if X.preventJoinByTicket == True:
                        X.preventJoinByTicket = False
                        anu.updateGroup(X)
                    gurl = anu.reissueGroupTicket(msg.to)
                    anu.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        anu.sendText(msg.to,"Can not be used outside the group")
                    else:
                        anu.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["G creator"]:
              if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)

#-----------------------[Add Staff Section]------------------------
            elif "Add staff @" in msg.text:
                if msg.toType == 2:
                    print "[Command]Staff add executing"
                    _name = msg.text.replace("Add staff @","Staf:on @")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    gs = kx.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Contact not found")
                    else:
                        for target in targets:
                            try:
                                admin.append(target)
                                cl.sendText(msg.to,"Added to the staff list")
                            except:
                                pass
                    print "[Command]Staff add executed"
                else:
                    cl.sendText(msg.to,"Command denied.")
                    cl.sendText(msg.to,"Admin permission required.")

            elif "Remove staff @" in msg.text:
                if msg.toType == 2:
                    print "[Command]Staff remove executing"
                    _name = msg.text.replace("Remove staff @","Staff expel:on @","Expel:on @")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    gs = kx.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Contact not found")
                    else:
                        for target in targets:
                            try:
                                admin.remove(target)
                                cl.sendText(msg.to,"Removed to the staff list")
                            except:
                                pass
                    print "[Command]Staff remove executed"
                else:
                    cl.sendText(msg.to,"Command denied.")
                    cl.sendText(msg.to,"Admin permission required.")

            elif msg.text in ["Staff list","stafflist"]:
                if admin == []:
                    cl.sendText(msg.to,"The staff list is empty")
                else:
                    cl.sendText(msg.to,"Waiting list...")
                    num=1
                    mc = "「Staff List」"
                    for mi_d in admin:
                        mc += "\n%i. %s" % (num, cl.getContact(mi_d).displayName)
                        num=(num+1)
                    cl.sendText(msg.to, mc)
#===========================================
            elif "Gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("Gourl: ","")
                    gurl = cl.reissueGroupTicket(gid)
                    cl.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    cl.sendText(msg.to,"Not for use less than group")
            elif "S1 gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("S1 gourl: ","Bot1 gurl")
                    x = ki.getGroup(gid)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        ki.updateGroup(x)
                    gurl = ki.reissueGroupTicket(gid)
                    ki.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    ki.sendText(msg.to,"Not for use less than group")
            elif "S2 gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("S2 gourl: ","Bot2 gurl")
                    x = kk.getGroup(gid)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        kk.updateGroup(x)
                    gurl = kk.reissueGroupTicket(gid)
                    kk.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    kk.sendText(msg.to,"Not for use less than group")
            elif "S3 gourl: " in msg.text:
                if msg.toType == 2:
                    gid = msg.text.replace("S3 gourl: ","Bot3 gurl")
                    x = kc.getGroup(gid)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        kc.updateGroup(x)
                    gurl = kc.reissueGroupTicket(gid)
                    kc.sendText(msg.to,"http://line.me/R/ti/g/" + gurl)
                else:
                    kc.sendText(msg.to,"Not for use less than group")
            elif msg.text.lower() == 'gcreator':
                if msg.toType == 2:
                    msg.contentType = 13
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                        msg.contentMetadata = {'mid': gCreator}
                        gCreator1 = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    cl.sendText(msg.to, "Group Creator : " + gCreator1)
                    cl.sendMessage(msg)
#========================================
            elif msg.text in ["Comment bl "]:
                wait["wblack"] = True
                cl.sendText(msg.to,"add to comment bl")
            elif msg.text in ["Comment wl "]:
                wait["dblack"] = True
                cl.sendText(msg.to,"wl to comment bl")
            elif msg.text in ["Comment bl confirm"]:
                if wait["commentBlack"] == {}:
                    cl.sendText(msg.to,"confirmed")
                else:
                    cl.sendText(msg.to,"Blacklist s")
                    mc = ""
                    for mi_d in wait["commentBlack"]:
                        mc += "・" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc)

            elif msg.text in ["Clock:on","Clock on","Jam on","Jam:on"]:
                if wait["clock"] == True:
                    cl.sendText(msg.to,"Clock is already on . . .")
                else:
                    wait["clock"] = True
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"[%H:%M]")
                    profile = cl.getProfile()
                    profile.displayName = wait["cName"] + nowT
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"done")

            elif msg.text in ["Clock:off","Clock off","Jam off","Jam:off"]:
                if wait["clock"] == False:
                    cl.sendText(msg.to,"already off")
                else:
                    wait["clock"] = False
                    cl.sendText(msg.to,"done")

            elif "Cc: " in msg.text:
                n = msg.text.replace("Cc: ","Update name: ","Myname: ")
                if len(n.decode("utf-8")) > 13:
                    cl.sendText(msg.to,"Sucsess name already changed . . .")
                else:
                    wait["cName"] = n
                    cl.sendText(msg.to,"Changed to:\n\n" + n)
            elif msg.text in ["Up"]:
                if wait["clock"] == True:
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"[%H:%M]")
                    profile = cl.getProfile()
                    profile.displayName = wait["cName"] + nowT
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"Refresh to update")
                else:
                    cl.sendText(msg.to,"Please turn on the name clock")

#========================================
            elif msg.text in [".","#set","Setlastpoint","Point"]:
                 if msg.toType == 2:
                    cl.sendText(msg.to, "Set reading point")
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                    except:
                        pass
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                    wait2['ROM'][msg.to] = {}
                    print wait
            elif msg.text in ["Read","#Cek","Readpoint"]:
                 if msg.toType == 2:
                    print "\nSider check aktif..."
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                print rom
                                chiya += rom[1] + "\n"

                        cl.sendText(msg.to, "┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\n༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅%s\n\n┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\n༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻\n┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\n%s\n\n═════════════════\nIn the last seen point:\n[%s]\n═════════════════\n" % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
                        print "\nReading Point Set..."
                        try:
                            del wait2['readPoint'][msg.to]
                            del wait2['readMember'][msg.to]
                        except:
                            pass
                        wait2['readPoint'][msg.to] = msg.id
                        wait2['readMember'][msg.to] = ""
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                        wait2['ROM'][msg.to] = {}
                        print wait
                        cl.sendText(msg.to, "Auto set reading point")
                    else:
                        cl.sendText(msg.to, "Set reading point first")
#========================================
            elif msg.text in ["DZion","Kicker","Neo join","All join"]:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
#                        kx.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        kc.updateGroup(G)
                        print "All_Kickers_Ok!"
                        G.preventJoinByTicket(G)
                        kc.updateGroup(G)
            elif msg.text in ["S1 join","S1 hadir","Bot1 join","A"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0 
                  Ti = cl.reissueGroupTicket(msg.to)
                  ki.acceptGroupInvitationByTicket(msg.to,Ti)                 
                  G = ki.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ki.updateGroup(G)
                  print "Kicker1_Ok!"
                  Ticket = ki.reissueGroupTicket(msg.to)
            elif msg.text in ["S2 join","S2join","B","Bot2 join"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0 
                  Ti = cl.reissueGroupTicket(msg.to)
                  kk.acceptGroupInvitationByTicket(msg.to,Ti)                 
                  G = kk.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kk.updateGroup(G)
                  print "Kicker2_Ok!"
                  Ticket = kk.reissueGroupTicket(msg.to)
            elif msg.text in ["S3 join","S3join","C","Bot3 join"]:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0 
                  Ti = cl.reissueGroupTicket(msg.to)
                  kc.acceptGroupInvitationByTicket(msg.to,Ti)                 
                  G = kc.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kc.updateGroup(G)
                  print "Kicker3_Ok!"
                  Ticket = kc.reissueGroupTicket(msg.to)

            elif msg.text in ["S4 join","S4join",'D']:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0 
                  Ti = cl.reissueGroupTicket(msg.to)
                  kx.acceptGroupInvitationByTicket(msg.to,Ti)                 
                  G = kx.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kx.updateGroup(G)
                  print "Kicker3_Ok!"
                  Ticket = kx.reissueGroupTicket(msg.to)

            elif msg.text in ["Bye all","Pulang","DZion @bye","Keluar","Bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    ki.leaveGroup(msg.to)
                    kk.leaveGroup(msg.to)
                    kc.leaveGroup(msg.to)
#                    kx.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["S1 @bye","S1bye","Bot1 @bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    ki.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["S2 @bye","S2bye","Bot2 @bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    kk.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["S3 @bye","S3bye","Bot3 @bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    kc.leaveGroup(msg.to)
                except:
                    pass
            elif msg.text in ["Bye me","Bye bye"]:
                if msg.toType == 2:
                   X = cl.getGroup(msg.to)
                try:
                    cl.leaveGroup(msg.to)
                except:
                    pass

            elif "Mk:" in msg.text:
                  if msg.from_ in admin:
                       mk0 = msg.text.replace("Mk:","Fuck ","")
                       mk1 = mk0.lstrip()
                       mk2 = mk1.replace("@","")
                       mk3 = mk2.rstrip()
                       _name = mk3
                       gs = ki.getGroup(msg.to)
                       targets = []
                       for h in gs.members:
                           if _name in h.displayName:
                              targets.append(h.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist . . .")
                           pass
                       else:
                           for target in targets:
                               try:
                                 if msg.from_ not in target:
                                   ki.kickoutFromGroup(msg.to,[target])
                               except:                                                  random.choice(KAC2).kickoutFromGroup(msg.to,[target])                            
                               pass
#==========================================
            elif msg.text in ["Kill"]:
                if msg.toType == 2:
                    klist=[kc,kk,ki]
                    kicker = random.choice(klist)
                    group = kicker.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        ki.sendText(msg.to,"Fuck You")
                        kk.sendText(msg.to,"Fuck You")
                        return
                    for jj in matched_list:
                        try:
                            random.choice(KAC2).kickoutFromGroup(msg.to,[jj])
                            print (msg.to,[jj])
                        except:
                            pass
            elif "Cleanse" in msg.text:
                if msg.toType == 2:
                    print "ok"
                    _name = msg.text.replace("Cleanse","NK: ")
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    gs = kx.getGroup(msg.to)
                    cl.sendText(msg.to,"􂀁􀄃explosion􏿿 Just some casual cleansing 􂀁􀄃explosion􏿿")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found.")
                    else:
                        for target in targets:
                          if not target in Bots:
                            try:
                               random.choice(KAC).kickoutFromGroup(msg.to,[target])
                               print (msg.to,[g.mid])
                            except:
                                pass

            elif "Tkick" in msg.text:
                if msg.toType == 2:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                           cl.kickoutFromGroup(msg.to,[target])
                        except:
                           cl.sendText(msg.to,"Error")
            elif "Neo1 kick" in msg.text:
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           ki.kickoutFromGroup(msg.to,[target])
                       except:
                           ki.sendText(msg.to,"Error")
            elif ("Neo2 kick" in msg.text):
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           kk.kickoutFromGroup(msg.to,[target])
                       except:
                           kk.sendText(msg.to,"Error")
            elif "Neo3 kick" in msg.text:
                if msg.toType == 2:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           kc.kickoutFromGroup(msg.to,[target])
                       except:
                           kc.sendText(msg.to,"Error")
            elif "Blacklist " in msg.text:
                _name = msg.text.replace("Blacklist ","Ban: ")
                _kicktarget = _name.rstrip(' ')
                gs = ki.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _kicktarget == g.displayName:
                        targets.append(g.mid)
                        if targets == []:
                            ki.sendText(msg.to,"Not found . . .")
                        else:
                            for target in targets:
                                try:
                                    wait["blacklist"][target] = True
                                    f=codecs.open('st2__b.json','w','utf-8')
                                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                    kk.sendText(msg.to,"ヽ( ^ω^)ﾉ Success")
                                except:
                                    ki.sendText(msg.to,"error")
            elif "Ban:on" in msg.text:
                if msg.toType == 2:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            wait ["blacklist"][target] = True
                            f=codecs.open('st2__b.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"ヽ( ^ω^)ﾉ Success")
                        except:
                           pass
            elif "Unban:on" in msg.text:
                if msg.toType == 2:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del wait ["blacklist"][target]
                            f=codecs.open('st2__b.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendText(msg.to,"ヽ( ^ω^)ﾉ Success")
                        except:
                           pass
            elif ("Block" in msg.text):
                 if msg.toType == 2:
                     print "[BLock]Ok"
                     key = eval(msg.contentMetadata["MENTION"])
                     key["MENTIONEES"][0]["M"]
                     targets = []
                     for x in key["MENTIONEES"]:
                         targets.append(x["M"])
                     for target in targets:
                         try:
                            cl.blockContact(target)
                            cl.sendText(msg.to, "Success block contact~")
                         except Exception as e:
                            print e

            elif msg.text.lower() == 'blocklist':
                blockedlist = cl.getBlockedContactIds()
                cl.sendText(msg.to, "Please wait...")
                kontak = cl.getContacts(blockedlist)
                num=1
                msgs="[User Blocked List]\n"
                for ids in kontak:
                    msgs+="\n%i. %s" % (num, ids.displayName)
                    num=(num+1)
                msgs+="\n\nTotal %i blocked user(s)" % len(kontak)
                cl.sendText(msg.to, msgs) 

            elif msg.text.lower() == 'Clear banlist':
                wait["blacklist"] = {}
                cl.sendText(msg.to,"☑ Blacklist Cleared . . .")
            elif msg.text in ["Ban"]:
                wait["wblacklist"] = True
                cl.sendText(msg.to,"send contact to blacklist . . .")

            elif msg.text in ["Unban"]:
                wait["dblacklist"] = True
                cl.sendText(msg.to,"send contact to whitelist . . .")

            elif msg.text in ["Ban on repeat","Ban:repeat"]:
                wait["rblacklist"] = True
                cl.sendText(msg.to,"Send Contact to Banned . . .")

            elif msg.text in ["Unban on repeat","Unban:repeat"]:
                wait["rdblacklist"] = True
                cl.sendText(msg.to,"Send Contact to Unbanned . . .")

            elif msg.text in ["Repeat:off","Repeat off"]:
                wait["rblacklist"] = False
                wait["rdblacklist"] = False
                cl.sendText(msg.to,"Turn off repeat . . .")

            elif msg.text in ["Banlist"]:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Nothing banlist user . . .")
                else:
                    cl.sendText(msg.to,"Blacklist user")
                    num=1
                    mc = "User Blacklist\n"
                    for mi_d in wait["blacklist"]:
                        mc += "%i. %s\n" % (num, cl.getContact(mi_d).displayName)
                        num=(num+1)
                    cl.sendText(msg.to, mc + "")
            elif msg.text in ["Ban cek","Cekban","Bl check"]:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = "User Blacklist"
                    for mm in matched_list:
                        cocoa += "\n" + mm + "\n"
                    cl.sendText(msg.to, cocoa + "║➽")
            elif msg.text in ["Kill ban"]:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"There was no blacklist user . . .")
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                        ki.kickoutFromGroup(msg.to,[jj])
                        kk.kickoutFromGroup(msg.to,[jj])
                        kc.kickoutFromGroup(msg.to,[jj])
                        cl.sendText(msg.to,"Refusing blacklist user . . .")
                        kc.sendText(msg.to, "Done refusing blacklist in groups . . .")
#-----------------------------------------------
            elif "Kick" in msg.text:
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                targets = []
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                   try:
                      cl.kickoutFromGroup(msg.to,[target])
                   except:
                      pass
#-----------------------------------------------

            elif msg.text in ["Stest","Sp","Speed"]:
                start = time.time()
                cl.sendText(msg.to, "Waiting speed progresss...")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))
            elif msg.text in ["Allspeed"]:
                if msg.toType == 2:
                   start = time.time()
                   cl.sendText(msg.to, "Progress...")
                   elapsed_time = time.time() - start
                   cl.sendText(msg.to, "%sseconds" % (elapsed_time))
                   ki.sendText(msg.to, "%sseconds" % (elapsed_time))
                   kk.sendText(msg.to, "%sseconds" % (elapsed_time))
                   kc.sendText(msg.to, "%sseconds" % (elapsed_time))
                  # kx.sendText(msg.to, "%sseconds 􀨁􀄻double thumbs up􏿿" % (elapsed_time))

            elif msg.text in ["Tagall","Tag all","Tag"]:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    name = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in name:
                       akh = akh + int(5)
                       cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                       strt = strt + int(6)
                       akh = akh + 1
                       cb2 += "@neoo\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        cl.sendMessage(msg)
                    except Exception as error:
                        print error
            elif msg.text in ["Anu itu"]:
              if msg.toType ==2 :
                group = cl.getGroup(msg.to)
                nama = [contact.mid for contact in group.members]
                cb = ""
                cb2 = ""
                strt = int(0)
                akh = int(0)
                for md in nama:
                    akh = akh + int(5)
                    cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                    strt = strt + int(6)
                    akh = akh + 1
                    cb2 += "@neoo\n"
                cb = (cb[:int(len(cb)-1)])
                msg.contentType = 0
                msg.text = cb2
                msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                try:
                    cl.sendMessage(msg)
                except Exception as error:
                    print error
            elif msg.text in ["S1tag","Bot1 tag","Neo1 tagall"]:
                if msg.toType == 2:
                    group = ki.getGroup(msg.to)
                    name = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in name:
                       akh = akh + int(5)
                       cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                       strt = strt + int(6)
                       akh = akh + 1
                       cb2 += "@neoo\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        ki.sendMessage(msg)
                    except Exception as error:
                        print error
            elif msg.text in ["Neo2 tagall","S2tag","Bot2 tag"]:
                if msg.toType == 2:
                    group = kk.getGroup(msg.to)
                    name = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in name:
                       akh = akh + int(5)
                       cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                       strt = strt + int(6)
                       akh = akh + 1
                       cb2 += "@neoo\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        kk.sendMessage(msg)
                    except Exception as error:
                        print error
            elif msg.text in ["Neo3 tagall","S3tag","Bot3 tag"]:
                if msg.toType == 2:
                    group = kc.getGroup(msg.to)
                    name = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in name:
                       akh = akh + int(5)
                       cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                       strt = strt + int(6)
                       akh = akh + 1
                       cb2 += "@neoo\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        kc.sendMessage(msg)
                    except Exception as error:
                        print error
#========================================
            elif msg.text in ["Invite on","Invite:on"]:
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = True
                    cl.sendText(msg.to,"Send a contact to invite . . .")
            elif msg.text in ["Invite stop","Invite:off"]:
            	if msg.from_ in admin:
            	  if msg.toType == 2:
                    wait["akaInvite"] = False
                    cl.sendText(msg.to,"Invite Stoped . . .")
#========================================
            elif "Youtube" in msg.text:
                 query = msg.text.replace("Youtube","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'http://www.youtube.com/results'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'http://www.youtube.com' + a['href'] + a['title'])
            elif "Xvideo " in msg.text:
                 query = msg.text.replace("Xvideo","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'https://www.xvideos.com/result'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'https://www.xvideos.com' + a['href'] + a['title'])
            elif "Smule" in msg.text:
                 query = msg.text.replace("Smule","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'https://www.smule.com/result'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'https://www.smule.com' + a['href'] + a['title'])
            elif "Google" in msg.text:
                 query = msg.text.replace("Google","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'https://www.Google.com/result'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'https://www.Google.com' + a['href'] + a['title'])
            elif "Translete" in msg.text:
                 query = msg.text.replace("Translete","")
                 with requests.session() as s:
                     s.headers['user-agent'] = 'Mozilla/5.0'
                     url = 'https://www.translete.com/result'
                     params = {'search_query': query}
                     r = s.get(url, params=params)
                     soup = BeautifulSoup(r.content, 'html5lib')
                     for a in soup.select('.yt-lockup-title > a[title]'):
                         if '&List' not in a['href']:
                               cl.sendText(msg.to,'https://www.translete.com' + a['href'] + a['title'])
#-----------------------------------------------
            elif "Mid @" in msg.text:
            	if msg.from_ in admin:
                  _name = msg.text.replace("Mid @","")
                  _nametarget = _name.rstrip(' ')
                  gs = cl.getGroup(msg.to)
                  for g in gs.members:
                      if _nametarget == g.displayName:
                          cl.sendText(msg.to, g.mid)
                      else:
                          pass
            elif ("Upic" in msg.text):
                   key = eval(msg.contentMetadata["MENTION"])
                   key1 = key["MENTIONEES"][0]["M"]
                   mi = cl.getProfileImages(key1)
                   cl.sendText(msg.to,"[image]    \n\n" + key1)
            elif ("Ubeyground" in msg.text):
                   key = eval(msg.contentMetadata["MENTION"])
                   key1 = key["MENTIONEES"][0]["M"]
                   mi = cl.getBeygroundImages(key1)
                   cl.sendText(msg.to,"[beyground]    \n\n" +key1)
            elif ("Uc" in msg.text):
                   key = eval(msg.contentMetadata["MENTION"])
                   key1 = key["MENTIONEES"][0]["M"]
                   mi = cl.getContact(key1)
                   cl.sendText(msg.to,"[Mid]  \n\n" + key1)
            elif msg.text in ["Backup","Mybackup"]:
                    try:
                       cl.updateDisplayPicture(backup.pictureStatus)
                       cl.updateProfile(backup)
                       cl.sendText(msg.to, "Backuping settings sucsess. . .")
                    except Exception as e:
                       cl.sendText(msg.to, str(e))
                    else:
                       pass
        if op.type == 55:
            print "[READ_MESSAGE]"
            try:
                if op.param1 in wait2['readPoint']:
                    Nama = cl.getContact(op.param2).displayName
                    if Nama in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n-> " + Nama
                        wait2['ROM'][op.param1][op.param2] = "-> " + Nama
                        wait2['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                else:
                    cl.sendText
            except:
                pass

        if op.type == 59:
            print op


    except Exception as error:
        print error


def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
def nameUpdate():
    while True:
        try:
        #while a2():
            #pass
            if wait["clock"] == True:
                now2 = datetime.now()
                nowT = datetime.strftime(now2,"(%H:%M)")
                profile = cl.getProfile()
                profile.displayName = wait["cName"] + nowT
                cl.updateProfile(profile)
            time.sleep(600)
        except:
            pass
thread2 = threading.Thread(target=nameUpdate)
thread2.daemon = True
thread2.start()

def autolike():
     for zx in range(0,50):
        hasil = cl.activity(limit=100000000)
        if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
          try:
            cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
            cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto Like by ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ AND ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
            ki.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
            ki.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto Like by ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ AND ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
            kk.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
            kk.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto Like by ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ AND ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
            kc.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
            kc.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto Like by ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ AND ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
            #ki4.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
            #ki4.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto Like by ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ AND ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
            #ki5.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
            #ki5.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto Like by ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ AND ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
            #ki6.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
            #ki6.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto Like by ༺₦Ξ࿋(´ﻌ`)₮ΞᏜѪℬ࿋₮™༻ AND I✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈")
            print "Like"
            print "Like"
            print "Like"
          except:
            pass
        else:
            print "Liked"
     time.sleep(100000000)
thread2 = threading.Thread(target=autolike)
thread2.daemon = True
thread2.start()

while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)
